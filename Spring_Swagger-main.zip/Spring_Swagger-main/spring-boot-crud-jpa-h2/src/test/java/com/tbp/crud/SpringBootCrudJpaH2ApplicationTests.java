package com.tbp.crud;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootCrudJpaH2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
