

# Spring Boot CRUD application using JPA and H2 Database

>RestControllers

> Dao Layer as JPA

> H2 As Database

package com.tbp.crud;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootCrudJpaH2Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootCrudJpaH2Application.class, args);
	}

}


```

---

## Installation

- Just Clone this repo
- Run mvn clean 

