package com.example.ecommerce;

import com.codeborne.selenide.Configuration;
import com.codeborne.selenide.Selenide;
import com.codeborne.selenide.logevents.SelenideLogger;
import io.qameta.allure.selenide.AllureSelenide;
import org.testng.annotations.*;

import static org.testng.Assert.*;

import static com.codeborne.selenide.Condition.attribute;
import static com.codeborne.selenide.Condition.visible;
import static com.codeborne.selenide.Selenide.*;

public class MainPageTest {
    MainPage mainPage = new MainPage();

    @BeforeClass
    public static void setUpAll() {
        Configuration.browserSize = "1280x800";
        SelenideLogger.addListener("allure", new AllureSelenide());
    }

    @BeforeMethod
    public void setUp() {
        open("https://demowebshop.tricentis.com/");
    }

    @Test
    public void search() {
        mainPage.searchButton.click();

        $("[data-test='search-box-text']").sendKeys("computer");
        $("button[data-test='search-box-button']").click();

        $("input[data-test='search-box-text']").shouldHave(attribute("value", "computer"));
    }

    @Test
    public void login(){
        $x("//a[contains(@class, 'ico-login') and text() = 'Log in']").click();
        $x("//input[contains(@class,'email')]").sendKeys("manzmehadi1@gmail.com");
        $x("//input[contains(@class,'password')]").sendKeys("Mehek@110");
        $x("//input[contains(@class,'login-button')]").click();
        $x("//input[contains(@class,'search-box-text')]").sendKeys("computer");
        $x("//a[contains(@id,'ui-id-2')]").click();
        $x("//input[contains(@id,'add-to-cart-button-72')]").click();
        $x("//a[contains(@class,'ico-logout') and text() = 'Log out']").click();

        //ico-logout
        //add-to-cart-button-72
        //search-box-button
    }

    @Test
    public void toolsMenu() {
        mainPage.toolsMenu.hover();

        $("a[data-test='ico-login']").shouldBe(visible);
    }

    @Test
    public void navigationToAllTools() {
        mainPage.seeAllToolsButton.click();

        $("#products-page").shouldBe(visible);

        assertEquals(Selenide.title(), "All Developer Tools and Products by JetBrains");
    }
}
